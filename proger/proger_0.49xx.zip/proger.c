/*
 * proger.c
 *
 *  Created on: 08.06.2014
 *      Author: aivanov
 *      version 0.33
 */


#include "proger.h"


void proger_stop ()
{
	unsigned char *proger_adr;
	 proger_adr  = (unsigned char *) PROGER_CONFIG_ADDR;
	*proger_adr &= 0xFE;//stop proger
}/* proger_stop */

/*---------------------------------------------------------------------------*/


void proger_start ()
{
	unsigned char *proger_adr;
	 proger_adr  = (unsigned char *) PROGER_CONFIG_ADDR;
	*proger_adr |= 0x01;//start proger
}/* proger_start */

/*---------------------------------------------------------------------------*/

int proger_rd_acquisition_info (unsigned char *array, unsigned int byte_count)
{
	volatile unsigned char *proger_proc_adr_clr, *proger_proc_adr_inc, *proger_proc_adr_dta;
	volatile unsigned int k;

	if (byte_count > 1024)
		return (0);

	proger_proc_adr_clr = (unsigned char *) MEM_ADDR_CNTR_PROC_CLR;
	proger_proc_adr_inc = (unsigned char *) MEM_ADDR_CNTR_PROC_INC;
	proger_proc_adr_dta = (unsigned char *) MEM_ADDR_CNTR_PROC_DTA;

	*proger_proc_adr_clr = 0x00;
	for (k = 0; k < byte_count; k++)
	{
		array[k] = *proger_proc_adr_dta;
		*proger_proc_adr_inc = 0x00;
	}

	return (1);
}/* proger_rd_acquisition_info */

/*---------------------------------------------------------------------------*/

int proger_wr_pulseprog (unsigned char *array, unsigned int byte_count)
{
	volatile unsigned char *proger_adr_tmp, *proger_adr_clr, *proger_adr_inc, *proger_adr_dta;
	volatile unsigned int k;

	proger_stop ();

	if (byte_count > PROGER_SIZE_IN_BYTES)
		return (0);

	proger_adr_tmp = (unsigned char *) MEM_ADDR_TMP_WORD;
	proger_adr_clr = (unsigned char *) MEM_ADDR_CNTR_CLR;
	proger_adr_inc = (unsigned char *) MEM_ADDR_CNTR_INC;
	proger_adr_dta = (unsigned char *) MEM_ADDR_FIFO_DTA;

	*proger_adr_clr = 0x00;
	for (k = 0; k < byte_count; k++)
	{
		*proger_adr_tmp = array[k];
		*proger_adr_dta = 0x00;
		*proger_adr_inc = 0x00;
	}

	return (1);
}/* proger_wr_pulseprog */

/*---------------------------------------------------------------------------*/

int proger_rd_pulseprog (unsigned char *array, unsigned int byte_count)
{
	volatile unsigned char *proger_adr_tmp, *proger_adr_clr, *proger_adr_inc, *proger_adr_dta;
	volatile unsigned int k, tmp;

	proger_stop ();

	if (byte_count > PROGER_SIZE_IN_BYTES)
		return (0);

	proger_adr_tmp = (unsigned char *) MEM_ADDR_TMP_WORD;
	proger_adr_clr = (unsigned char *) MEM_ADDR_CNTR_CLR;
	proger_adr_inc = (unsigned char *) MEM_ADDR_CNTR_INC;
	proger_adr_dta = (unsigned char *) MEM_ADDR_FIFO_DTA;

	*proger_adr_clr = 0x00;
	for (k = 0; k < byte_count; k++)
	{
		array[k] = *proger_adr_dta;
		tmp = array[k];
		*proger_adr_inc = 0x00;
	}

	return (1);
}/* proger_rd_pulseprog */

/*---------------------------------------------------------------------------*/

int proger_compare_pulseprog (unsigned char *array, unsigned int byte_count)
{
	volatile unsigned char *proger_adr_tmp, *proger_adr_clr, *proger_adr_inc, *proger_adr_dta;
	volatile unsigned int k, result;
	volatile unsigned char array_prog [PROGER_SIZE_IN_BYTES];

	proger_stop ();

	if (byte_count > PROGER_SIZE_IN_BYTES)
		return (0);

	proger_adr_tmp = (unsigned char *) MEM_ADDR_TMP_WORD;
	proger_adr_clr = (unsigned char *) MEM_ADDR_CNTR_CLR;
	proger_adr_inc = (unsigned char *) MEM_ADDR_CNTR_INC;
	proger_adr_dta = (unsigned char *) MEM_ADDR_FIFO_DTA;

	*proger_adr_clr = 0x00;
	for (k = 0; k < byte_count; k++)
	{
		array[k] = *proger_adr_dta;
		*proger_adr_inc = 0x00;
	}

	result = 1;

	for (k = 0; k < byte_count; k++)
	{
		if (array_prog[k] != array[k])
		{
			result = 0;
			break;
		}
	}

	return (result);
}/* proger_compare_pulseprog */

/*---------------------------------------------------------------------------*/

int proger_mem_init ()
{
	volatile unsigned char comm [4];
	volatile unsigned int k;

	proger_stop ();
	proger_reset_comm_fifo_counter();

	memset(comm, 0x00, 4);

	for (k = 0; k < PROG_MAX_COMMANDS; k++)
	{
		proger_wr_comm_arr_to_fifo (comm);
	}

	return (1);
}/* proger_mem_init */

/*---------------------------------------------------------------------------*/

int proger_mem_init2 ()
{
	volatile unsigned char array [PROGER_SIZE_IN_BYTES];
	volatile unsigned int k;

	proger_stop ();

	for (k = 0; k < PROGER_SIZE_IN_BYTES; k++)
	{
		array[k] = 0x00;
	}

	proger_wr_pulseprog ( (unsigned char *) array, PROGER_SIZE_IN_BYTES);

	return (1);
}/* proger_mem_init2 */

/*---------------------------------------------------------------------------*/

int proger_test_mem_pulseprog ()
{
	volatile unsigned char array [PROGER_SIZE_IN_BYTES];
	volatile unsigned int k, result;

	for (k = 0; k < PROGER_SIZE_IN_BYTES; k++)
	{
		array[k] = k;
	}

	result = proger_compare_pulseprog ( (unsigned char *) array, PROGER_SIZE_IN_BYTES);

	proger_mem_init ();

	return (result);
}/* proger_test_mem_pulseprog */

/*---------------------------------------------------------------------------*/

int proger_rd_echo_count (void)
{
	volatile unsigned int *proger_proc_adr_echo_count;
	volatile unsigned int echo_count;

	proger_proc_adr_echo_count = (unsigned int *) MEM_ADDR_ECHO_CNTR;

	echo_count = *proger_proc_adr_echo_count;

	return (echo_count);
}/* proger_rd_echo_count */

/*---------------------------------------------------------------------------*/

int proger_rd_adc_points_count (void)
{
	volatile unsigned int *proger_proc_adr_adc_points_count;
	volatile unsigned int adc_points_count;
	unsigned int max_num_points_in_UPP_DMA_buf, tmp_mask;

#if ( (UPP_DMA_BUF_SIZE == 64) || (UPP_DMA_BUF_SIZE == 128) || (UPP_DMA_BUF_SIZE == 256) )

	proger_proc_adr_adc_points_count = (unsigned int *) MEM_ADDR_ADC_PNTS_CNTR;

	adc_points_count = *proger_proc_adr_adc_points_count;

	//Calculating number of received points if upp DMA chunk is UPP_DMA_BUF_SIZE
	max_num_points_in_UPP_DMA_buf = UPP_DMA_BUF_SIZE >> 1;
	tmp_mask = ~(max_num_points_in_UPP_DMA_buf - 1);
	adc_points_count = adc_points_count & tmp_mask;

	return (adc_points_count);

#else
#error UPP_DMA_BUF_SIZE could be only 64 or 128 or 256 !
	check upp.h and proger.h
#endif

}/* proger_rd_adc_points_count */

/*---------------------------------------------------------------------------*/

int proger_reset_comm_fifo_counter (void)
{
	volatile unsigned char *proger_adr_clr;

	proger_stop ();

	proger_adr_clr = (unsigned char *) MEM_ADDR_CNTR_CLR;

	*proger_adr_clr = 0x00;

	return (1);
}/* proger_reset_comm_fifo_counter */

/*---------------------------------------------------------------------------*/

int proger_wr_comm_arr_to_fifo (volatile unsigned char *comm)
{
	volatile unsigned char *proger_adr_tmp, *proger_adr_inc, *proger_adr_dta;
	volatile unsigned int k;

	proger_stop ();

	proger_adr_tmp = (unsigned char *) MEM_ADDR_TMP_WORD;
	proger_adr_inc = (unsigned char *) MEM_ADDR_CNTR_INC;
	proger_adr_dta = (unsigned char *) MEM_ADDR_FIFO_DTA;

	for (k = 0; k < 4; k++)
	{
		*proger_adr_tmp = comm[k];
		*proger_adr_dta = 0x00;
		*proger_adr_inc = 0x00;
	}

	return (1);
}/* proger_wr_comm_arr_to_fifo */

/*---------------------------------------------------------------------------*/

int proger_wr_comm_to_fifo (unsigned char comm, unsigned char arg1, unsigned char arg2, unsigned char arg3)
{
	volatile unsigned char *proger_adr_tmp, *proger_adr_inc, *proger_adr_dta;
	volatile unsigned int k;

	proger_stop ();

	proger_adr_tmp = (unsigned char *) MEM_ADDR_TMP_WORD;
	proger_adr_inc = (unsigned char *) MEM_ADDR_CNTR_INC;
	proger_adr_dta = (unsigned char *) MEM_ADDR_FIFO_DTA;

	*proger_adr_tmp = comm;
	*proger_adr_dta = 0x00;
	*proger_adr_inc = 0x00;

	*proger_adr_tmp = arg1;
	*proger_adr_dta = 0x00;
	*proger_adr_inc = 0x00;

	*proger_adr_tmp = arg2;
	*proger_adr_dta = 0x00;
	*proger_adr_inc = 0x00;

	*proger_adr_tmp = arg3;
	*proger_adr_dta = 0x00;
	*proger_adr_inc = 0x00;

	return (1);
}/* proger_wr_comm_arr_to_fifo */

/*---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/

int main_proger_wr_pulseprog_test_GPIO3 ()
{
	//unsigned char array [PROGER_SIZE_IN_BYTES], array_prog [PROGER_SIZE_IN_BYTES];
	unsigned int k, result;
	unsigned char array[PROGER_SIZE_IN_BYTES] = {

			//241	,	0	,	0x27	,	0x0F	, // 10 ms delay before RF pulses
			241	,	0	,	0x00	,	0x63	, // 10 ms delay before RF pulses

				210	,	0x00,	0x00,	0x10 | 0x00,	//out reg 4 goes high - awake led lights up //GPIO3 goes low - rf pulses started

			241	,	0	,	0x27	,	0x0F	, // 10 ms delay before RF pulses

				210	,	0x00,	0x00,	0x10 | 0x08,	//out reg 4 goes high - awake led lights up //GPIO3 goes low - rf pulses started

			241	,	0	,	0	,	9	, // duration of GPIO pulse

			//	231	,	0	,	0	,	200	, //RF pulse 20 mks

				210	,	0x00,	0x00,	0x10 | 0x08 | 0x04, //GPIO2 goes low - adc window started

				243	,	0	,	0x01,	0x2B, // ecos number = 300

			241	,	0	,	0x01	,	0xC1, // delay 450 mks

			241	,	0	,	0	,	99	,	 // adc time 100 mks

				242	,	0	,	0	,	1	,

			241	,	0	,	0x01	,	0xC1, // delay 450 mks

				242	,	0	,	0	,	0	, // adc off

				244	,	0	,	0	,	0	, // end of cycles

			241	,	0	,	0x27	,	0x0F	, // 10 ms delay after RF pulses

				210	,	0x00	,	0x00	,	0x10  | 0x08,	//GPIO2 goes high - adc window ended

			241	,	0	,	0	,	9	,

				210	,	0x00,	0x00,	0x00, //GPIO3 goes high -  RF pulses ended, awake led off

			241	,	0	,	0	,	19	,	// last delay

				243	,
				0	,
				0	,
				0	,

			241,	0x0F,	0x42,	0x3F,

				244	,
				0	,
				0	,
				0	,

				0	,
				0	,
				0	,
				0	,

	};


	proger_stop ();
	//proger_mem_init ();

	proger_wr_pulseprog (array, 25*4);

}/* main_proger_wr_pulseprog_test_GPIO3 */

int main_proger_wr_pulseprog_test_GPIO_48f ()
{
	//unsigned char array [PROGER_SIZE_IN_BYTES], array_prog [PROGER_SIZE_IN_BYTES];
	unsigned int k, result;
	unsigned char array[PROGER_SIZE_IN_BYTES] = {

			//241	,	0	,	0x27	,	0x0F	, // 10 ms delay before RF pulses
			241	,	0	,	0x00	,	0x63	, // 10 ms delay before RF pulses

				200	,	0x00,	0x00,	0x10 | 0x00,	//out reg 4 goes high - awake led lights up //GPIO3 goes low - rf pulses started

			241	,	0	,	0x27	,	0x0F	, // 10 ms delay before RF pulses

				200	,	0x00,	0x00,	0x10 | 0x08,	//out reg 4 goes high - awake led lights up //GPIO3 goes low - rf pulses started

			241	,	0	,	0	,	9	, // duration of GPIO pulse

			//	231	,	0	,	0	,	200	, //RF pulse 20 mks

				200	,	0x00,	0x00,	0x10 | 0x08 | 0x04, //GPIO2 goes low - adc window started

				243	,	0	,	0x01,	0x2C, // ecos number = 300

			241	,	0	,	0x01	,	0xC1, // delay 450 mks

			241	,	0	,	0	,	99	,	 // adc time 100 mks

				242	,	0	,	0	,	1	,

			241	,	0	,	0x01	,	0xC1, // delay 450 mks

				242	,	0	,	0	,	0	, // adc off

				244	,	0	,	0	,	0	, // end of cycles

			241	,	0	,	0x27	,	0x0F	, // 10 ms delay after RF pulses

				200	,	0x00	,	0x00	,	0x10  | 0x08,	//GPIO2 goes high - adc window ended

			241	,	0	,	0	,	9	,

				200	,	0x00,	0x00,	0x00, //GPIO3 goes high -  RF pulses ended, awake led off

			241	,	0	,	0	,	19	,	// last delay

			241,	0x0F,	0x42,	0x3F,

				0	,
				0	,
				0	,
				0	,

	};


	proger_stop ();
	//proger_mem_init ();

	proger_wr_pulseprog (array, 25*4);

}/* main_proger_wr_pulseprog_test_GPIO_48f */

int main_proger_wr_pulseprog_test_GPIO_48f_COUNTER ()
{
	//unsigned char array [PROGER_SIZE_IN_BYTES], array_prog [PROGER_SIZE_IN_BYTES];
	unsigned int k, result;
	unsigned char array[PROGER_SIZE_IN_BYTES] = {

			//241	,	0	,	0x27	,	0x0F	, // 10 ms delay before RF pulses
			241	,	0	,	0x00	,	0x63	, // 10 ms delay before RF pulses

				200	,	0x00,	0x00,	0x10 | 0x00,	//out reg 4 goes high - awake led lights up //GPIO3 goes low - rf pulses started

				250	,	0xFF,	0xFF,	0xFF, // activate test configuration

			241	,	0	,	0x27	,	0x0F	, // 10 ms delay before RF pulses

				200	,	0x00,	0x00,	0x10 | 0x08,	//out reg 4 goes high - awake led lights up //GPIO3 goes low - rf pulses started

			241	,	0	,	0	,	9	, // duration of GPIO pulse

			//	231	,	0	,	0	,	200	, //RF pulse 20 mks

				200	,	0x00,	0x00,	0x10 | 0x08 | 0x04, //GPIO2 goes low - adc window started

				243	,	0	,	0x01,	0x2C, // begin cycle, ecos number = 300

			241	,	0	,	0x01	,	0xC1, // delay 450 mks

			241	,	0	,	0	,	99	,	 // adc time 100 mks

				242	,	0	,	0	,	1	,

				201	,	0	,	12	,	0	, //write to adc processing memory

				202	,	1	,	2	,	3	,

				202	,	4	,	5	,	6	,

				202	,	7	,	8	,	9	,

			241	,	0	,	0x01	,	0xC1, // delay 450 mks

				242	,	0	,	0	,	0	, // adc off

				244	,	0	,	0	,	0	, // end of cycle

			241	,	0	,	0x27	,	0x0F	, // 10 ms delay after RF pulses

				200	,	0x00	,	0x00	,	0x10  | 0x08,	//GPIO2 goes high - adc window ended

			241	,	0	,	0	,	9	,

				200	,	0x00,	0x00,	0x00, //GPIO3 goes high -  RF pulses ended, awake led off

			241	,	0	,	0	,	19	,	// last delay

				243	,
				0	,
				0	,
				0	,

			241,	0x0F,	0x42,	0x3F,

				244	,
				0	,
				0	,
				0	,

				0	, //restart
				0	,
				0	,
				0	,

	};


	proger_stop ();
	//proger_mem_init ();

	proger_wr_pulseprog (array, 27*4);

}/* main_proger_wr_pulseprog_test_GPIO_48f_COUNTER */


int main_proger_wr_pulseprog_test_GPIO_48f_ADC ()
{
	//unsigned char array [PROGER_SIZE_IN_BYTES], array_prog [PROGER_SIZE_IN_BYTES];
	unsigned int k, result;
	unsigned char array[PROGER_SIZE_IN_BYTES] = {

			//241	,	0	,	0x27	,	0x0F	, // 10 ms delay before RF pulses
			241	,	0	,	0x00	,	0x63	, // 10 ms delay before RF pulses

				200	,	0x00,	0x00,	0x10 | 0x00,	//out reg 4 goes high - awake led lights up //GPIO3 goes low - rf pulses started

				//250	,	0xFF,	0xFF,	0xFF, // activate test configuration

			241	,	0	,	0x27	,	0x0F	, // 10 ms delay before RF pulses

				200	,	0x00,	0x00,	0x10 | 0x08,	//out reg 4 goes high - awake led lights up //GPIO3 goes low - rf pulses started

			241	,	0	,	0	,	9	, // duration of GPIO pulse

			//	231	,	0	,	0	,	200	, //RF pulse 20 mks

				200	,	0x00,	0x00,	0x10 | 0x08 | 0x04, //GPIO2 goes low - adc window started

				243	,	0	,	0x01,	0x2C, // begin cycle, ecos number = 300

			241	,	0	,	0x01	,	0xC1, // delay 450 mks

			241	,	0	,	0	,	99	,	 // adc time 100 mks

				242	,	0	,	0	,	1	,

				201	,	0	,	12	,	0	, //write to adc processing memory

				202	,	1	,	2	,	3	,

				202	,	4	,	5	,	6	,

				202	,	7	,	8	,	9	,

			241	,	0	,	0x01	,	0xC1, // delay 450 mks

				242	,	0	,	0	,	0	, // adc off

				244	,	0	,	0	,	0	, // end of cycle

			241	,	0	,	0x27	,	0x0F	, // 10 ms delay after RF pulses

				200	,	0x00	,	0x00	,	0x10  | 0x08,	//GPIO2 goes high - adc window ended

			241	,	0	,	0	,	9	,

				200	,	0x00,	0x00,	0x00, //GPIO3 goes high -  RF pulses ended, awake led off

			241	,	0	,	0	,	19	,	// last delay

				243	,
				0	,
				0	,
				0	,

			241,	0x0F,	0x42,	0x3F,

				244	,
				0	,
				0	,
				0	,

				0	, //restart
				0	,
				0	,
				0	,

	};


	proger_stop ();
	//proger_mem_init ();

	proger_wr_pulseprog (array, 27*4);

}/* main_proger_wr_pulseprog_test_GPIO_48f_ADC */

int main_proger_wr_pulseprog_test_GPIO_48f_ADC_Diel ()
{
	//unsigned char array [PROGER_SIZE_IN_BYTES], array_prog [PROGER_SIZE_IN_BYTES];
	unsigned int k, result;
	unsigned char array[PROGER_SIZE_IN_BYTES] = {

			//241	,	0	,	0x27	,	0x0F	, // 10 ms delay before RF pulses
			241	,	0	,	0x00	,	0x63	, // 10 ms delay before RF pulses

				200	,	0x00,	0x00,	0x10 | 0x00,	//out reg 4 goes high - awake led lights up //GPIO3 goes low - rf pulses started

				//250	,	0xFF,	0xFF,	0xFF, // activate test configuration

			241	,	0	,	0x27	,	0x0F	, // 10 ms delay before RF pulses

				200	,	0x00,	0x00,	0x10 | 0x08,	//out reg 4 goes high - awake led lights up //GPIO3 goes low - rf pulses started

			241	,	0	,	0	,	9	, // duration of GPIO pulse

			//	231	,	0	,	0	,	200	, //RF pulse 20 mks

				200	,	0x00,	0x00,	0x10 | 0x08 | 0x04, //GPIO2 goes low - adc window started

				243	,	0	,	0x01,	0x2C, // begin cycle, ecos number = 300

			241	,	0	,	0x01	,	0xC1, // delay 450 mks

			241	,	0	,	0	,	99	,	 // adc time 100 mks

				242	,	0	,	0	,	1	,

				201	,	0	,	12	,	0	, //write to adc processing memory

				202	,	1	,	2	,	3	,

				202	,	4	,	5	,	6	,

				202	,	7	,	8	,	9	,

			241	,	0	,	0x01	,	0xC1, // delay 450 mks

				242	,	0	,	0	,	0	, // adc off

				244	,	0	,	0	,	0	, // end of cycle

			241	,	0	,	0x00	,	0x02	, // 2 mks interval for writing to processing memory

				201	,	0	,	12	,	10	, //write to processing memory

				202	,	11	,	12	,	13	,

				202	,	14	,	15	,	16	,

				202	,	17	,	18	,	19	,

			241	,	0	,	0x27	,	0x0F	, // 10 ms interval for read ext. device

				200	,	0x00,	0x00,	0x10 | 0x08 | 0x04 | 0x01, //GPIO[0] goes low - ext dev window started

			241	,	0	,	0x00	,	9	, // 10 mks interval end of read ext. device

					200	,	0x00,	0x00,	0x10 | 0x08 | 0x04, //GPIO[0] goes low - ext dev window ended

			241	,	0	,	0x27	,	0x0F	, // 10 ms delay after RF pulses

				200	,	0x00	,	0x00	,	0x10  | 0x08,	//GPIO2 goes high - adc window ended

			241	,	0	,	0	,	9	,

				200	,	0x00,	0x00,	0x00, //GPIO3 goes high -  RF pulses ended, awake led off

			241	,	0	,	0	,	19	,	// last delay

				243	,
				0	,
				0	,
				0	,

			241,	0x0F,	0x42,	0x3F,

				244	,
				0	,
				0	,
				0	,

				0	, //restart
				0	,
				0	,
				0	,

	};


	proger_stop ();
	//proger_mem_init ();

	proger_wr_pulseprog (array, 35*4);

	return(1);

}/* main_proger_wr_pulseprog_test_GPIO_48f_ADC_Diel */

int main_proger_wr_pulseprog_test_GPIO_48f_ADC_FID ()
{
	//unsigned char array [PROGER_SIZE_IN_BYTES], array_prog [PROGER_SIZE_IN_BYTES];
	//unsigned int k, result;
	unsigned char array[PROGER_SIZE_IN_BYTES] = {

			241	,	0	,	0x27	,	0x0F	, // 10 ms delay before all operations

				200	,	0x00,	0x00,	0x00,	//out reg 6 goes high - awake led lights up //GPIO3 goes low - rf pulses started
				//250	,	0xFF,	0xFF,	0xFF, // activate test configuration


			241	,	0	,	0x27	,	0x0F	, // 10 ms delay before ADC FULL WINDOW

				200	,	0x00,	0x00,	0x08,	//out reg 4 goes high - awake led lights up //GPIO3 goes low - rf pulses started

				243	,	0	,	0x00,	0x01, // begin cycle, ecos number = 1

			241	,	0	,	0	,	99	,	 // adc time 100 mks, NOISE ADC ON

					242	,	0	,	0	,	1	,

					201	,	1	,	0	,	1	, //write to adc processing memory COM/Number params/Type of returned data

					//202	,	2	,	0	,	2	,

			241	,	0	,	0	,	0	,	 // adc time 1 mks, NOISE ADC OFF

					242	,	0	,	0	,	0	,


			241	,	0	,	0	,	99	, // RF pulse interval

				222	,	0	,	0x03	,	0xE8	, //RF pulse 100 mks

				200	,	0x00,	0x00,	0x08 | 0x04, //GPIO2 goes low - adc window started


			241	,	0	,	0	,	99	,	 // adc time 100 mks

				242	,	0	,	0	,	1	,

				201	,	2	,	0	,	2	, //write to adc processing memory COM/Number params/Type of returned data


			241	,	0	,	0	,	99	,	 // time 100 mks

				242	,	0	,	0	,	0	, // adc off

				244	,	0	,	0	,	0	, // end of cycle


			241	,	0	,	0x27	,	0x0F	, // 10 ms interval for read ext. device

				200	,	0x00,	0x00,	0x10 | 0x08 | 0x04 | 0x01, //GPIO[0] goes low - ext dev window started

			241	,	0	,	0x00	,	9	, // 10 mks interval end of read ext. device

					200	,	0x00,	0x00,	0x10 | 0x08 | 0x04, //GPIO[0] goes low - ext dev window ended

			241	,	0	,	0x27	,	0x0F	, // 10 ms delay after RF pulses

				200	,	0x00	,	0x00	,	0x10  | 0x08,	//GPIO2 goes high - adc window ended

			241	,	0	,	0	,	9	,

				200	,	0x00,	0x00,	0x00, //GPIO3 goes high -  RF pulses ended, awake led off

			241	,	0	,	0	,	19	,	// last delay

				243	,
				0	,
				0	,
				0	,

			241,	0x0F,	0x42,	0x3F, // 1s delay

				244	,
				0	,
				0	,
				0	,

				0	, //restart
				0	,
				0	,
				0	,

	};


	proger_stop ();
	//proger_mem_init ();

	proger_wr_pulseprog (array, 32*4);

	return(1);

}/* main_proger_wr_pulseprog_test_GPIO_48f_ADC_Diel */

int main_proger_wr_pulseprog_test_FRQ ()
{
	//unsigned char array [PROGER_SIZE_IN_BYTES], array_prog [PROGER_SIZE_IN_BYTES];
	unsigned int k, result;

	unsigned char array[PROGER_SIZE_IN_BYTES];
	//memset(array, 0x00, PROGER_SIZE_IN_BYTES);
	proger_stop ();
	proger_mem_init();
	proger_reset_comm_fifo_counter();

	proger_wr_comm_to_fifo ( COM_TIME, 0, 0, 2);
		proger_wr_comm_to_fifo ( COM_PROC_CONTROL_REG, 0, 0, 0x80); // Busy led on
		proger_wr_comm_to_fifo ( COM_TEST_CONF_WR, 0, 0, 0);
		proger_wr_comm_to_fifo ( COM_OFS01, 0x1A, 0x36, 0xE2);
		//proger_wr_comm_to_fifo ( COM_OFS01, 0xE5, 0xC9, 0x1E);
		proger_wr_comm_to_fifo ( COM_CYCLE_OPEN, 0, 0, 2);
		proger_wr_comm_to_fifo ( COM_CYCLE_OPEN, 0, 0, 3);
	proger_wr_comm_to_fifo ( COM_TIME, 0, 0, 1);
		proger_wr_comm_to_fifo ( COM_RF01, 0, 0, 5);
		proger_wr_comm_to_fifo ( COM_CYCLE_CLOSE, 0, 0, 0);
		proger_wr_comm_to_fifo ( COM_CYCLE_CLOSE, 0, 0, 0);
	proger_wr_comm_to_fifo ( COM_TIME, 0, 0, 1);
		proger_wr_comm_to_fifo ( COM_RF01, 0, 0, 10);
	proger_wr_comm_to_fifo ( COM_TIME, 0, 0, 99);
		proger_wr_comm_to_fifo ( COM_ADS_IN, 0, 0, 1);
		proger_wr_comm_to_fifo ( COM_WR_RST_PROC_MEM, 2, 1, 0);
		proger_wr_comm_to_fifo ( COM_WR_INC_PROC_MEM, 5, 4, 3);
		proger_wr_comm_to_fifo ( COM_WR_INC_PROC_MEM, 8, 7, 6);
		proger_wr_comm_to_fifo ( COM_WR_INC_PROC_MEM, 11, 10, 9);
		proger_wr_comm_to_fifo ( COM_WR_INC_PROC_MEM, 14, 13, 12);
	proger_wr_comm_to_fifo ( COM_TIME, 0, 0x01, 0xC1);// time interval 450 mks
		proger_wr_comm_to_fifo ( COM_ADS_IN, 0, 0, 0);
	proger_wr_comm_to_fifo ( COM_TIME, 0, 0x01, 0xC1);// time interval 10 ms for delay after RF pulses
		proger_wr_comm_to_fifo ( COM_PROC_CONTROL_REG, 0, 0, 0x00); // Busy led off
	proger_wr_comm_to_fifo ( COM_TIME, 0x0F, 0x42, 0x3F); // last delay
	proger_wr_comm_to_fifo ( COM_TIME, 0x00, 0x00, 0x01);
		proger_wr_comm_to_fifo ( COM_RET, 0x0F, 0x42, 0x3F); // last delay

}// main_proger_wr_pulseprog_test_FRQ

int main_proger_wr_pulseprog_test_FID ()
{
	unsigned int result = 0;

	proger_stop ();
	proger_mem_init();
	proger_reset_comm_fifo_counter();



	proger_wr_comm_to_fifo ( COM_TIME, 0, 0, 2);
		proger_wr_comm_to_fifo ( COM_PROC_CONTROL_REG, 0, 0, 0x80); // Busy led on
		proger_wr_comm_to_fifo ( COM_TEST_CONF_WR, 0, 0, 0);
		proger_wr_comm_to_fifo ( COM_OFS01, 0x1A, 0x36, 0xE2);
		//proger_wr_comm_to_fifo ( COM_OFS01, 0xE5, 0xC9, 0x1E);
		proger_wr_comm_to_fifo ( COM_CYCLE_OPEN, 0, 0, 2);
		proger_wr_comm_to_fifo ( COM_CYCLE_OPEN, 0, 0, 3);
	proger_wr_comm_to_fifo ( COM_TIME, 0, 0, 1);
		proger_wr_comm_to_fifo ( COM_RF01, 0, 0, 5);
		proger_wr_comm_to_fifo ( COM_CYCLE_CLOSE, 0, 0, 0);
		proger_wr_comm_to_fifo ( COM_CYCLE_CLOSE, 0, 0, 0);
	proger_wr_comm_to_fifo ( COM_TIME, 0, 0, 1);
		proger_wr_comm_to_fifo ( COM_RF01, 0, 0, 10);
	proger_wr_comm_to_fifo ( COM_TIME, 0, 0, 99);
		proger_wr_comm_to_fifo ( COM_ADS_IN, 0, 0, 1);
		proger_wr_comm_to_fifo ( COM_WR_RST_PROC_MEM, 2, 1, 0);
		proger_wr_comm_to_fifo ( COM_WR_INC_PROC_MEM, 5, 4, 3);
		proger_wr_comm_to_fifo ( COM_WR_INC_PROC_MEM, 8, 7, 6);
		proger_wr_comm_to_fifo ( COM_WR_INC_PROC_MEM, 11, 10, 9);
		proger_wr_comm_to_fifo ( COM_WR_INC_PROC_MEM, 14, 13, 12);
	proger_wr_comm_to_fifo ( COM_TIME, 0, 0x01, 0xC1);// time interval 450 mks
		proger_wr_comm_to_fifo ( COM_ADS_IN, 0, 0, 0);
	proger_wr_comm_to_fifo ( COM_TIME, 0, 0x01, 0xC1);// time interval 10 ms for delay after RF pulses
		proger_wr_comm_to_fifo ( COM_PROC_CONTROL_REG, 0, 0, 0x00); // Busy led off
	proger_wr_comm_to_fifo ( COM_TIME, 0x0F, 0x42, 0x3F); // last delay
	proger_wr_comm_to_fifo ( COM_TIME, 0x00, 0x00, 0x01);
		proger_wr_comm_to_fifo ( COM_RET, 0x0F, 0x42, 0x3F); // last delay

}// main_proger_wr_pulseprog_test_FRQ

